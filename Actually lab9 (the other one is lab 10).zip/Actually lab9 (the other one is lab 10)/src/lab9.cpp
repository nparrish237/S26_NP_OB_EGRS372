//Includes all of the ROS libraries needed
#include "ros/ros.h"
#include "std_msgs/Byte.h"
#include "geometry_msgs/PoseStamped.h"
#include "move_base_msgs/MoveBaseActionResult.h"
#include <sstream>
#include <fstream>
#include <string>
#include <cmath>
#define PI 3.141592653589793
#include <ros/package.h>
#include "lab9/parameter_update.h"


//These libraries are needed for the dynamic reconfiguring
//DoubleParameter could be substituted for IntParameter if ints needed to be set instead of doubles, this applies for all variables
#include <dynamic_reconfigure/DoubleParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/Config.h>
#include <ros/service.h>

double p1_x = 2.23;
double p1_y = 5.02;

double p2_x = 2.23;
double p2_y = 4;

double p3_x = 2.23;
double p3_y = 3;

double p4_x = 2.23;
double p4_y = 2;

double p5_x = 2.23;
double p5_y = 1;
int inc = 1;

double p_x[] = {p1_x, p2_x, p3_x, p4_x, p5_x};
double p_y[] = {p1_y, p2_y, p3_y, p4_y, p5_y};

// State variables
int state = 1;
int button_value = 0;
int goal_value = 0;
int battery_low = 0;
int btn_count = 0x0000;
int battery_confirm = 0;
int places = 0;
int force_home = 0;
float battery_voltage=0;

//Uncomment this and replace {type} with the type of message when needed
//#include "std_msgs/{type}.h"





void goal_reaction(const move_base_msgs::MoveBaseActionResult goal_result)
{ 
  goal_value = goal_result.status.status;
}





int main(int argc, char **argv)
{
  //names the programs node
  ros::init(argc, argv, "lab9");
  ros::NodeHandle n;

  //sets the frequency for which the program sleeps at. 10=1/10 second
  ros::Rate loop_rate(10);

  //creating the dynamic reconfigure variables
  dynamic_reconfigure::ReconfigureRequest srv_req;
  dynamic_reconfigure::ReconfigureResponse srv_resp;
  dynamic_reconfigure::DoubleParameter double_param;
  dynamic_reconfigure::Config conf;
  
  //Declare publishers
  ros::Publisher pose_pub = n.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal",1,true); //Goal for naviagtion
  ros::Publisher param_update = n.advertise<lab9::parameter_update>("parameter_status",1);

  //Declare subsriber
  ros::Subscriber goal_sub    = n.subscribe("/move_base/result",1000,goal_reaction); //Monitor if the MR has reached its goal
  ros::service::waitForService("/move_base/DWAPlannerROS/set_parameters");

  lab9::parameter_update status_msg;

//----------------------------------------------------------------------------------------------------
  // Orientation
  double psi_offset = 1 * (PI/180);
  double z_quat = 0.0;
  double w_quat = 1.0;

  geometry_msgs::PoseStamped pstamp; //MR goal messege

  
  // Common pose setup
  pstamp.header.frame_id = "map";
  pstamp.pose.orientation.x = 0.0;
  pstamp.pose.orientation.y = 0.0;
  pstamp.pose.orientation.z = z_quat;
  pstamp.pose.orientation.w = w_quat;

  for (int i = 0; i < 5; i++) {
  // ================= GO HOME FIRST =================


//----------------------------------------------------------------------------------------------------

double var1 = 0.0;
double var2d = 0.0;
double var3 = 0.0;
double var4d = 0.0;


char var2f = 'f';
char var4f = 'f';

//std::ifstream file("parameters.txt");
std::string path = ros::package::getPath("lab9") + "/parameters.txt";
//std::ifstream file(path);
std::ifstream file(path.c_str());

if (!file.is_open()) {
    std::cerr << "Error opening file\n";
    return 1;
}

for (int j = 0; j < inc; j++) {
std::string line;
std::getline(file, line);

std::stringstream ss(line);
std::string token;

// -------------------- parse --------------------

std::getline(ss, token, ',');
var1 = atof(token.c_str());

std::getline(ss, token, ',');
if (!token.empty())
    var2f = token[0];

std::getline(ss, token, ',');
var3 = atof(token.c_str());

std::getline(ss, token, ',');
if (!token.empty())
    var4f = token[0];
}

file.close();
inc++;

// -------------------- logic --------------------

if (var2f == 't') {
    var2d = -.5;
} else {
    var2d = 0.0;
}

if (var4f == 't') {
    var4d = 0.1;
} else {
    var4d = 10.0;
}
ROS_INFO("var1 = %f", var1);
ROS_INFO("var2 = %f", var2d);
ROS_INFO("var3 = %f", var3);
ROS_INFO("var4 = %f", var4d);


//----------------------------------------------------------------------------------------------------

  dynamic_reconfigure::ReconfigureRequest srv_req;
  dynamic_reconfigure::ReconfigureResponse srv_resp;
  dynamic_reconfigure::Config conf;

  dynamic_reconfigure::DoubleParameter double_param;


//--------- Update Msg --------------------------------------
  status_msg.max_lin_spd = var1;
  status_msg.max_rot_spd = var3;
  status_msg.backward_move = var2f;
  status_msg.adjust_orient = var4f;
  param_update.publish(status_msg);
  ros::spinOnce();
  loop_rate.sleep();
    

  //setting max_vel_x
  double_param.name = "max_vel_x";
  double_param.value = var1;
  conf.doubles.push_back(double_param);

  //srv_req is whats actually sent to the service and is set to be equal to conf which should contain the parameters
  srv_req.config = conf;

  //calling the service to actually set the parameters
  ros::service::call("/move_base/DWAPlannerROS/set_parameters", srv_req, srv_resp);

  //clearing conf so that it can be used later to set the parameters
  //if this is not done the values for max_vel_x and min_vel_x are still saved in conf
  conf.doubles.clear();

  ros::spinOnce();
  loop_rate.sleep();

  //setting min_vel_x
  double_param.name = "min_vel_x";
  double_param.value = var2d;
  conf.doubles.push_back(double_param);

  //srv_req is whats actually sent to the service and is set to be equal to conf which should contain the parameters
  srv_req.config = conf;

  //calling the service to actually set the parameters
  ros::service::call("/move_base/DWAPlannerROS/set_parameters", srv_req, srv_resp);

  //clearing conf so that it can be used later to set the parameters
  //if this is not done the values for max_vel_x and min_vel_x are still saved in conf
  conf.doubles.clear();

  ros::spinOnce();
  loop_rate.sleep();

  //setting max_rot_vel
  double_param.name = "max_rot_vel";
  double_param.value = var3;
  conf.doubles.push_back(double_param);

  //srv_req is whats actually sent to the service and is set to be equal to conf which should contain the parameters
  srv_req.config = conf;

  //calling the service to actually set the parameters
  ros::service::call("/move_base/DWAPlannerROS/set_parameters", srv_req, srv_resp);

  //clearing conf so that it can be used later to set the parameters
  //if this is not done the values for max_vel_x and min_vel_x are still saved in conf
  conf.doubles.clear();

  ros::spinOnce();
  loop_rate.sleep();

  //setting yaw_goal_tolerance
  double_param.name = "yaw_goal_tolerance";
  double_param.value = var4d;
  conf.doubles.push_back(double_param);

  //srv_req is whats actually sent to the service and is set to be equal to conf which should contain the parameters
  srv_req.config = conf;

  //calling the service to actually set the parameters
  ros::service::call("/move_base/DWAPlannerROS/set_parameters", srv_req, srv_resp);

  //clearing conf so that it can be used later to set the parameters
  //if this is not done the values for max_vel_x and min_vel_x are still saved in conf
  conf.doubles.clear();

  ros::spinOnce();
  loop_rate.sleep();

  pstamp.pose.position.x = p_x[i];
  pstamp.pose.position.y = p_y[i];
  pstamp.header.stamp = ros::Time::now();

  goal_value = 0; // Reset goal value so robot knows when it reaches its goal
  ros::Duration(2.0).sleep(); //Wait 2 seconds so the goal properly registers
  pose_pub.publish(pstamp);


  //Move to home position
  while(goal_value != 3 && ros::ok())
  {
    ros::spinOnce();
    loop_rate.sleep();
  }



  }
  return 0;
}

